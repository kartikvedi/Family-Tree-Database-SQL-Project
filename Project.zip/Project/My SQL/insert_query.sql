-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------


USE FamilyTreeDB;

-- Insert data into the Person table
INSERT INTO Person (Name, DateOfBirth, DateOfDeath, Picture)
VALUES ('John Doe', '1980-01-01', NULL, NULL);

INSERT INTO Person (Name, DateOfBirth, DateOfDeath, Picture)
VALUES ('Jane Doe', '1985-02-02', NULL, NULL);

INSERT INTO Person (Name, DateOfBirth, DateOfDeath, Picture)
VALUES ('Jay Doe', '2000-03-01', NULL, NULL);

INSERT INTO Person (Name, DateOfBirth, DateOfDeath, Picture)
VALUES ('Kia Doe', '2000-05-02', NULL, NULL);


INSERT INTO Person_Address VALUES(99, '669', 'New York', 'NY');
INSERT INTO Person_Address VALUES(88, '691', 'Los Angeles', 'CA');
INSERT INTO Person_Address VALUES(2, '679', 'Nairobi', 'NBI');
INSERT INTO Person_Address VALUES(3, '727', 'Kisumu', 'KSM');

-- Insert data into the Marriage table
INSERT INTO Marriage (DateOfMarriage, DateOfDivorce, DateOfRemarriage, PersonID1, PersonID2)
VALUES ('2000-03-03', NULL, NULL, 1, 2);

-- Insert data into the ChildParentRelationship table
INSERT INTO ChildParentRelationship (RelationshipType, ChildID, ParentID)
VALUES ('Biological', 3, 1);

INSERT INTO ChildParentRelationship (RelationshipType, ChildID, ParentID)
VALUES ('Biological', 4, 2);


-- Insert data into the WorkHistory table
INSERT INTO WorkHistory (CompanyName, JobTitle, StartDate, Enddate, PersonID)
VALUES ('Google', 'Software Engineer', '2010-05-05', NULL, 1);

INSERT INTO WorkHistory (CompanyName, JobTitle, StartDate, Enddate, PersonID)
VALUES ('Microsoft', 'Software Engineer', '2015-06-06', NULL, 2);


-- Insert data into the EducationHistory table
INSERT INTO EducationHistory (SchoolName, Degree, StartDate, Enddate, PersonID)
VALUES ('Stanford University', 'Bachelor of Science in Computer Science', '2005-09-09', '2009-06-06', 1);

INSERT INTO EducationHistory (SchoolName, Degree, StartDate, Enddate, PersonID)
VALUES ('Harvard University', 'Master of Science in Computer Science', '2009-09-09', '2011-06-06', 2);

INSERT INTO EducationHistory (SchoolName, Degree, StartDate, Enddate, PersonID)
VALUES ('Douglas University', 'Master of Science in Computer Science', '2009-09-09', '2011-06-06', 3);

INSERT INTO EducationHistory (SchoolName, Degree, StartDate, Enddate, PersonID)
VALUES ('IPU University', 'Master of Science in Computer Science', '2009-09-09', '2011-06-06', 4);


INSERT INTO Person_attends_school VALUES (1,1);
INSERT INTO Person_attends_school VALUES (2,2);

-- Insert data into the Place table
INSERT INTO Place (Address, City, State, ZipCode)
VALUES ('123 Main Street', 'Anytown', 'CA', '91234');

INSERT INTO Place (Address, City, State, ZipCode)
VALUES ('456 Elm Street', 'Anytown', 'CA', '91234');

-- Insert data into the Event table
INSERT INTO Events (NameOfEvent, DateOfEvent, Description, PersonID)
VALUES ('Birthday', '2023-08-04', 'Happy birthday to me!', 1);

INSERT INTO Events (NameOfEvent, DateOfEvent, Description, PersonID)
VALUES ('Wedding', '2000-03-03', 'Married the love of my life!', 2);

-- Insert data into the PersonPlace table
INSERT INTO PersonPlace (PersonID, PlaceID)
VALUES (1, 1);

INSERT INTO PersonPlace (PersonID, PlaceID)
VALUES (2, 2);


