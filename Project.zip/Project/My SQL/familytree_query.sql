 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------
-- Q1 Find all persons who were born before a specific date:
SELECT *
FROM Person
WHERE DateOfBirth < '1990-01-01';

-- Q2 Find all persons who are currently married:
SELECT p.Name, m.DateOfMarriage
FROM Person p
INNER JOIN Marriage m ON p.PersonID = m.PersonID1
WHERE m.DateOfDivorce IS NULL;


-- Q3 Find the number of children for each parent, grouped by gender:
SELECT p.PersonID, COUNT(*) AS child_count
FROM Person p
INNER JOIN ChildParentRelationship cpr ON p.PersonID = cpr.ParentID
GROUP BY p.PersonID;

-- Q4 Find all persons who have worked at a specific company:
SELECT p.Name, w.CompanyName
FROM Person p
INNER JOIN WorkHistory w ON p.PersonID = w.PersonID
WHERE w.CompanyName = 'Google';

-- Q5 Find all persons who have graduated from a specific school:
SELECT p.Name, eh.SchoolName
FROM Person p
INNER JOIN EducationHistory eh ON p.PersonID = eh.PersonID
WHERE eh.SchoolName = 'Stanford University';

-- Q6 Find all places where a specific person has lived:

SELECT pl.Address, pl.City, pl.State, pl.ZipCode
FROM Person p
INNER JOIN PersonPlace pp ON p.PersonID = pp.PersonID
INNER JOIN Place pl ON pp.PlaceID = pl.PlaceID
WHERE p.PersonID = 3;

-- Q7 Find all events that a specific person has attended:
SELECT ev.NameOfEvent, ev.DateOfEvent, ev.Description
FROM Person p
INNER JOIN Events ev ON p.PersonID = ev.PersonID
WHERE p.PersonID = 1;

-- Q8 Find the most common degree among all education histories:

SELECT eh.Degree, COUNT(*) AS degree_count
FROM EducationHistory eh
GROUP BY eh.Degree
ORDER BY degree_count DESC
LIMIT 1;

-- Q9 Find the number of events attended per person, grouped by event type:
SELECT ev.NameOfEvent AS event_type, COUNT(*) AS event_count
FROM Events ev
INNER JOIN Person p ON ev.PersonID = p.PersonID
GROUP BY ev.NameOfEvent;

-- Q10 Find the most frequent job title changes among all persons:
SELECT p.Name, w.JobTitle, w.StartDate, w.EndDate
FROM Person p
INNER JOIN WorkHistory w ON p.PersonID = w.PersonID
ORDER BY w.StartDate ASC;

-- Q11 Find the most common educational path for persons with a specific degree:
SELECT eh.SchoolName, eh.Degree, eh.StartDate, eh.EndDate
FROM EducationHistory eh
WHERE eh.Degree = 'PhD'

-- Q12 Find the most popular event types among persons who have attended multiple events:
SELECT ev.NameOfEvent AS event_type, COUNT(*) AS event_count
FROM Events ev
INNER JOIN Person p ON ev.PersonID = p.PersonID
GROUP BY ev.NameOfEvent
HAVING COUNT(*) > 1;

-- Q13 Find the most common company for first work experiences:

SELECT w.CompanyName, COUNT(*) AS first_job_count
FROM WorkHistory w
INNER JOIN Person p ON p.PersonID = w.PersonID
WHERE w.StartDate = (SELECT MIN(StartDate) FROM WorkHistory WHERE PersonID = p.PersonID)
GROUP BY w.CompanyName
ORDER BY first_job_count DESC
LIMIT 1;

-- Q14 Find the most common place where each person has attended events:
SELECT p.Name, ev.NameOfEvent, ev.DateOfEvent
FROM Person p
INNER JOIN Events ev ON p.PersonID = ev.PersonID
GROUP BY p.Name, ev.NameOfEvent, ev.DateOfEvent
ORDER BY COUNT(*) DESC
LIMIT 1;

USE Family_Tree_Database  


-- Q15 Creating a view that joins Person and Education_History tables

CREATE VIEW Person_Education_View AS
SELECT P.PersonID, P.Name, P.DateOfBirth, P.DateOfDeath,
       EH.EducationHistoryID, EH.SchoolName, EH.StartDate AS EducationStart, EH.EndDate AS EducationEnd, EH.Degree
FROM Person P
JOIN Person_attends_school PAS ON P.PersonID = PAS.PersonID
JOIN EducationHistory EH ON PAS.SchoolID = EH.EducationHistoryID;

SELECT *
FROM Person_Education_View;
 
 
 -- Q16 Delete Entry for deleting a persons_Address from our database

DELETE FROM Person_Address
WHERE PersonID = 3;


-- Q17 The total count of Persons in our Family Tree Database (Aggregate function)

SELECT COUNT(PersonID) AS TotalPersons
FROM Person;

-- Q18  Nested query for people with graduation events

SELECT P.PersonID, P.Name
FROM Person P
WHERE P.PersonID IN (SELECT E.PersonID FROM Events E WHERE E.NameOfEvent LIKE '%Graduation%');

-- Q19 Left Join to Display Persons with Education History

SELECT P.PersonID, P.Name, EH.Schoolname, EH.Degree
FROM Person P
LEFT JOIN Person_attends_school PAS ON P.PersonID = PAS.PersonID
LEFT JOIN EducationHistory EH ON PAS.SchoolID = EH.EducationHistoryID;

-- Q20 Update query for updating last name for Person ID is 99

UPDATE Person
SET Name = 'Kariuki'
WHERE PersonID = 2;






















