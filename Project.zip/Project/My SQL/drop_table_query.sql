-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

USE FamilyTreeDB;

DROP TABLE Marriage;
DROP TABLE ChildParentRelationship;
DROP TABLE WorkHistory;
DROP TABLE EducationHistory;
DROP TABLE Place;
DROP TABLE Events;
DROP TABLE Person_attends_school;
DROP TABLE Person_Address;
DROP TABLE PersonPlace;
DROP TABLE Person;

DROP database FamilyTreeDB;

/* All of these statements should work on both MySQL and MS SQL Server. However, there are a few minor differences between the two DBMSs. For example, in MySQL, the DROP TABLE statement can be used to drop a table even if it contains foreign key constraints. In MS SQL Server, the DROP TABLE statement cannot be used to drop a table if it contains foreign key constraints. Instead, you must first drop the foreign key constraints before dropping the table.*/  

/* Another difference between the two DBMSs is that MySQL allows you to drop a table even if there are active transactions that are referencing the table. MS SQL Server does not allow this. If there are active transactions that are referencing the table, you must first commit or rollback the transactions before dropping the table.*/