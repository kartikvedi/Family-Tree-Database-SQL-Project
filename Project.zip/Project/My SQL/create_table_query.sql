-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

-- CREATE DATABASE FamilyTreeDB;
USE FamilyTreeDB;

CREATE TABLE Person (
    PersonID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    DateOfBirth DATE NOT NULL,
    DateOfDeath DATE NULL,
    Picture VARCHAR(255) NULL
);

CREATE TABLE Person_Address (
    PersonID INT,
    Zipcode VARCHAR(10)NOT NULL,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    PRIMARY KEY (PersonID, Zipcode)
);


CREATE TABLE Marriage (
    MarriageID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    DateOfMarriage DATE NOT NULL,
    DateOfDivorce DATE NULL,
    DateOfRemarriage DATE NULL,
    PersonID1 INT NOT NULL,
    PersonID2 INT NOT NULL,
    FOREIGN KEY (PersonID1) REFERENCES Person(PersonID),
    FOREIGN KEY (PersonID2) REFERENCES Person(PersonID)
);

CREATE TABLE ChildParentRelationship (
    RelationshipID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    RelationshipType VARCHAR(255) NOT NULL,
    ChildID INT NOT NULL,
    ParentID INT NOT NULL,
    FOREIGN KEY (ChildID) REFERENCES Person(PersonID),
    FOREIGN KEY (ParentID) REFERENCES Person(PersonID)
);


CREATE TABLE WorkHistory (
    WorkHistoryID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    CompanyName VARCHAR(255) NOT NULL,
    JobTitle VARCHAR(255) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NULL,
    PersonID INT NOT NULL,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE EducationHistory (
    EducationHistoryID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    SchoolName VARCHAR(255) NOT NULL,
    Degree VARCHAR(255) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NULL,
    PersonID INT NOT NULL,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE Person_attends_school (
    PersonID INT,
    SchoolID INT,
    PRIMARY KEY (PersonID, SchoolID),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID),
    FOREIGN KEY (SchoolID) REFERENCES EducationHistory(EducationHistoryID)
);


CREATE TABLE Place (
    PlaceID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Address VARCHAR(255) NOT NULL,
    City VARCHAR(255) NOT NULL,
    State VARCHAR(255) NOT NULL,
    ZipCode VARCHAR(255) NOT NULL
);

CREATE TABLE Events (
    EventID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    NameOfEvent VARCHAR(255) NOT NULL,
    DateOfEvent DATE NOT NULL,
    Description VARCHAR(255) NOT NULL,
    PersonID INT NOT NULL,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE PersonPlace (
    PersonID INT NOT NULL,
    PlaceID INT NOT NULL,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID),
    FOREIGN KEY (PlaceID) REFERENCES Place(PlaceID)
);


