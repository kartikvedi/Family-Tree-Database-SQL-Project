-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

--CREATE DATABASE Family_Tree_Database; 
USE Family_Tree_Database;

CREATE TABLE Person (
    PersonID INT PRIMARY KEY,
    LName VARCHAR(50) UNIQUE NOT NULL,
    FName VARCHAR(50) UNIQUE NOT NULL,
    DateofBirth DATE NOT NULL,
    DateofDeath DATE,
    Picture VARBINARY(MAX) NULL

);

CREATE TABLE Person_Address (
    PersonID INT,
    Zipcode VARCHAR(10)NOT NULL,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    PRIMARY KEY (PersonID, Zipcode)
);

CREATE TABLE Education_History (
    SchoolID INT PRIMARY KEY,
    Schoolname VARCHAR(100) UNIQUE NOT NULL,
    Startdate DATE NOT NULL,
    Enddate DATE NOT NULL,
    Degree VARCHAR(50) NOT NULL
);

CREATE TABLE Person_attends_school (
    PersonID INT,
    SchoolID INT,
    PRIMARY KEY (PersonID, SchoolID),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID),
    FOREIGN KEY (SchoolID) REFERENCES Education_History(SchoolID)
);

CREATE TABLE Work_History (
    CompanyID INT PRIMARY KEY,
    CompanyName VARCHAR(100) UNIQUE NOT NULL,
    Startdate DATE,
    Enddate DATE,
    Jobtitle VARCHAR(50) NOT NULL,
    PersonID INT

	FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE Events (
    EventID INT PRIMARY KEY,
    Eventname VARCHAR(100) UNIQUE NOT NULL,
    Eventdate DATE NOT NULL,
    EventDesc VARCHAR(MAX),
    PersonID INT

	FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);

CREATE TABLE Motherhood (
    ChildID INT,
    MotherID INT NOT NULL,
    PRIMARY KEY (ChildID, MotherID),
    FOREIGN KEY (ChildID) REFERENCES Person(PersonID),
    FOREIGN KEY (MotherID) REFERENCES Person(PersonID)
);

CREATE TABLE Fatherhood (
    ChildID INT,
    FatherID INT NOT NULL,
    PRIMARY KEY (ChildID, FatherID),
    FOREIGN KEY (ChildID) REFERENCES Person(PersonID),
    FOREIGN KEY (FatherID) REFERENCES Person(PersonID)
);

CREATE TABLE Marriage (
    HusbandID INT NOT NULL,
    WifeID INT NOT NULL,
    PRIMARY KEY (HusbandID, WifeID),
    FOREIGN KEY (HusbandID) REFERENCES Person(PersonID),
    FOREIGN KEY (WifeID) REFERENCES Person(PersonID)
);

