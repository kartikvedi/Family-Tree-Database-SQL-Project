-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

USE Family_Tree_Database;

-- Q1 Find all persons who were born before a specific date:
SELECT *
FROM Person
WHERE DateofBirth < '2004-01-20';

--Q2 Find all persons who are currently married:
SELECT P.*
FROM Person P
JOIN Marriage M ON P.PersonID = M.HusbandID OR P.PersonID = M.WifeID;

--Q3 Find the number of children for each parent, grouped by gender:
SELECT F.FatherID AS ParentID, COUNT(F.ChildID) AS NumberOfChildren, 'Father' AS Gender
FROM Fatherhood F
GROUP BY F.FatherID
UNION ALL
SELECT M.MotherID AS ParentID, COUNT(M.ChildID) AS NumberOfChildren, 'Mother' AS Gender
FROM Motherhood M
GROUP BY M.MotherID;

--Q4 Find all persons who have worked at a specific company:
SELECT P.*
FROM Person P
JOIN Work_History WH ON P.PersonID = WH.PersonID
WHERE WH.CompanyName = 'Company ABC'; 

--Q5 Find all persons who have graduated from a specific school:
SELECT P.*
FROM Person P
JOIN Person_attends_school PAS ON P.PersonID = PAS.PersonID
JOIN Education_History EH ON PAS.SchoolID = EH.SchoolID
WHERE EH.Schoolname = 'Douglas University';

--Q6 Find all places where a specific person has lived:
SELECT PA.*
FROM Person_Address PA
WHERE PA.PersonID = 30; 

--Q7 Find all events that a specific person has attended:
SELECT E.*
FROM Events E
WHERE E.PersonID = 99; 

--Q8 Find the most common place where each person has attended events:
SELECT PA.PersonID, PA.City, COUNT(*) AS Frequency
FROM Person_Address PA
JOIN Events E ON PA.PersonID = E.PersonID
GROUP BY PA.PersonID, PA.City
ORDER BY Frequency DESC;

--Q9 Find the number of events attended per person, grouped by event type:
SELECT P.PersonID, P.FName, P.LName, E.Eventname, COUNT(*) AS EventCount
FROM Person P
JOIN Events E ON P.PersonID = E.PersonID
GROUP BY P.PersonID, P.FName, P.LName, E.Eventname;

--The LIMIT clause is not supported in Microsoft SQL Server.
--Instead, we used the TOP keyword to achieve similar functionality for limiting the number of records returned.

--Q10 Find the most common degree among all education histories:
SELECT TOP 1 Degree, COUNT(*) AS Frequency
FROM Education_History
GROUP BY Degree
ORDER BY Frequency DESC;

--Q11 Find the most common company for first work experiences:
SELECT TOP 1 WH.CompanyName, COUNT(*) AS Frequency
FROM Work_History WH
WHERE Startdate = (
    SELECT MIN(Startdate)
    FROM Work_History
    WHERE PersonID = WH.PersonID
)
GROUP BY WH.CompanyName
ORDER BY Frequency DESC;

-- Q12 Find the most frequent job title changes among all persons:
SELECT TOP 1 PersonID, COUNT(*) AS JobTitleChanges
FROM (
    SELECT PersonID, Jobtitle, ROW_NUMBER() OVER (PARTITION BY PersonID ORDER BY Startdate) AS RN
    FROM Work_History
) AS JobChanges
WHERE RN > 1
GROUP BY PersonID
ORDER BY JobTitleChanges DESC;

-- Q13 Find the most common educational path for persons with a specific degree:
SELECT TOP 1 EH1.Schoolname, EH2.Schoolname, COUNT(*) AS Frequency
FROM Person_attends_school PAS1
JOIN Education_History EH1 ON PAS1.SchoolID = EH1.SchoolID
JOIN Person_attends_school PAS2 ON PAS1.PersonID = PAS2.PersonID
JOIN Education_History EH2 ON PAS2.SchoolID = EH2.SchoolID AND EH1.SchoolID != EH2.SchoolID
WHERE EH1.Degree = 'Bachelor of Science' 
GROUP BY EH1.Schoolname, EH2.Schoolname
ORDER BY Frequency DESC;

-- Q14 Find the most popular event types among persons who have attended multiple events:
SELECT TOP 1 E.Eventname, COUNT(*) AS Frequency
FROM Events E
WHERE E.PersonID IN (
    SELECT E2.PersonID
    FROM Events E2
    GROUP BY E2.PersonID
    HAVING COUNT(*) > 1
)
GROUP BY E.Eventname
ORDER BY Frequency DESC;


SELECT *
FROM Person_Education_View;

-- Q15 The total count of Persons in our Family Tree Database (Aggregate function)

SELECT COUNT(PersonID) AS TotalPersons
FROM Person

-- Q16 Average Age of Persons (Aggregate function)

SELECT AVG(DATEDIFF(YEAR, DateofBirth, GETDATE())) AS AvgAge
FROM Person

-- Q17  Nested query for people with graduation events

SELECT P.PersonID, P.FName, P.LName
FROM Person P
WHERE P.PersonID IN (SELECT E.PersonID FROM Events E WHERE E.Eventname LIKE '%Graduation%');

-- Q18 Left Join to Display Persons with Education History

SELECT P.PersonID, P.FName, P.LName, EH.Schoolname, EH.Degree
FROM Person P
LEFT JOIN Person_attends_school PAS ON P.PersonID = PAS.PersonID
LEFT JOIN Education_History EH ON PAS.SchoolID = EH.SchoolID;

-- Q19 Update query for updating last name for Person ID is 99

UPDATE Person
SET LName = 'Kariuki'
WHERE PersonID = 99;

-- Q20 Creating a view that joins Person and Education_History tables

CREATE VIEW Person_Education_View AS
SELECT P.PersonID, P.LName, P.FName, P.DateOfBirth, P.DateOfDeath,
       EH.SchoolID, EH.Schoolname, EH.Startdate AS EducationStart, EH.Enddate AS EducationEnd, EH.Degree
FROM Person P
JOIN Person_attends_school PAS ON P.PersonID = PAS.PersonID
JOIN Education_History EH ON PAS.SchoolID = EH.SchoolID;



SELECT *
FROM Person_Education_View;

