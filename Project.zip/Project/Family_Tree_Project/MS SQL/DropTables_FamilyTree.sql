-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

USE Family_Tree_Database  


DROP TABLE IF EXISTS Motherhood;
DROP TABLE IF EXISTS Fatherhood;
DROP TABLE IF EXISTS Person_Address;
DROP TABLE IF EXISTS Marriage;
DROP TABLE IF EXISTS Person_attends_school;
DROP TABLE IF EXISTS Education_History;
DROP TABLE IF EXISTS Work_History;
DROP TABLE IF EXISTS Events;
DROP TABLE IF EXISTS Person;



