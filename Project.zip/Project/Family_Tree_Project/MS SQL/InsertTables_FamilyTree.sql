-- 
-- Group 13
-- Members: Kartik Vedi, MySQL Expert
--          Caroline Waruinu Kahare, MS SQL Expert
-- --------------------------------------

USE Family_Tree_Database;

INSERT INTO Person VALUES(99, 'Carol', 'Lisa', '1996-07-18', NULL, 484);
INSERT INTO Person VALUES(88, 'Kartika', 'Doje', '1985-05-20', NULL, 269);
INSERT INTO Person VALUES(2, 'Kim', 'Lee', '1970-07-18', NULL, 4567);
INSERT INTO Person VALUES(3, 'Ward', 'Johns', '1960-05-20', NULL, 9475);
INSERT INTO Person VALUES(303, 'Mila', 'Paul', '1987-07-18', NULL, 648);
INSERT INTO Person VALUES(6893, 'Liz', 'Kiiru', '1982-01-20', NULL, 2897);
INSERT INTO Person VALUES(30, 'Moan', 'Moe', '1981-07-18', NULL, 467906);
INSERT INTO Person VALUES(104, 'Kahare', 'Moses', '2001-05-20', NULL, 544747);
INSERT INTO Person VALUES(709, 'Simon', 'Paulau', '2002-07-18', NULL, 6486);
INSERT INTO Person VALUES(341, 'Stanley', 'Kimeu', '2004-01-20', NULL, 28979);
INSERT INTO Person VALUES(342, 'Editha', 'Wanjirus', '2005-07-18', NULL, 4696);
INSERT INTO Person VALUES(343, 'ana', 'wambui', '2006-07-20', NULL, 469356);

INSERT INTO Person_Address VALUES(99, '669', 'New York', 'NY');
INSERT INTO Person_Address VALUES(88, '691', 'Los Angeles', 'CA');
INSERT INTO Person_Address VALUES(2, '679', 'Nairobi', 'NBI');
INSERT INTO Person_Address VALUES(3, '727', 'Kisumu', 'KSM');
INSERT INTO Person_Address VALUES(30, '903', 'Machakos', 'MSC');
INSERT INTO Person_Address VALUES(303, '700', 'Naivasha', 'NVS');
INSERT INTO Person_Address VALUES(6893, '001', 'South Africa', 'SA');

INSERT INTO Education_History VALUES(1779, 'Douglas University', '2000-09-01', '2004-05-15', 'Bachelor of Science');
INSERT INTO Education_History VALUES(1768, 'Nairobi College', '2005-08-20', '2007-12-30', 'Associate Degree');
INSERT INTO Education_History VALUES(1773, 'Waters University', '2001-09-01', '2005-05-15', 'Bachelor of Technology');
INSERT INTO Education_History VALUES(1774, 'Kisumu College', '2006-08-20', '2008-12-30', 'Medicine');



INSERT INTO Person_attends_school VALUES (99, 1779);
INSERT INTO Person_attends_school VALUES (30, 1768);
INSERT INTO Person_attends_school VALUES (88, 1773);
INSERT INTO Person_attends_school VALUES (6893, 1774);
INSERT INTO Person_attends_school VALUES (2, 1779);
INSERT INTO Person_attends_school VALUES (3, 1779);


INSERT INTO Work_History VALUES (11, 'Company ABC', '2010-01-05', '2015-07-20', 'Software Engineer', 88);
INSERT INTO Work_History VALUES (14, 'Innovex', '2002-09-05', '2007-07-20', 'Cooking', 3);
INSERT INTO Work_History VALUES (13, 'Company DEF', '2016-02-10', '2019-12-30', 'Marketing Manager', 2);
INSERT INTO Work_History VALUES (15, 'Agile', '2000-09-19', '2002-07-17', 'Project Management', 30);
INSERT INTO Work_History VALUES (16, 'IBM', '2006-03-10', '2011-11-07', 'Trade', 6893);
INSERT INTO Work_History VALUES (17, 'Shippers', '2019-09-19', '2021-07-17', 'Project Management', 341);
INSERT INTO Work_History VALUES (18, 'Lotto', '2017-01-05', '2021-07-20', 'Project Management', 88);
INSERT INTO Work_History VALUES (20, 'Cassie', '2013-03-10', '2019-11-07', 'Cooking', 6893);
 

INSERT INTO Events VALUES (19, 'Birthday Party', '2022-01-15', 'birthday celebration', 104);
INSERT INTO Events VALUES (20, 'Thanksgiving', '2021-01-15', 'Thanksgiving', 343);
INSERT INTO Events VALUES (21, 'Graduation', '2020-09-06', 'Graduation', 30);
INSERT INTO Events VALUES (22, 'Graduation2', '2020-10-10', 'Graduation2', 99);
INSERT INTO Events VALUES (23, 'Graduation3', '2021-10-10', 'Graduation3', 6893);
INSERT INTO Events VALUES (24, 'Christmas', '2021-10-10', 'Christmas', 99);
INSERT INTO Events VALUES (25, 'Rememberance', '2022-10-10', 'Rememberance', 6893)

INSERT INTO Motherhood (ChildID, MotherID)
VALUES (88, 2);
INSERT INTO Motherhood (ChildID, MotherID)
VALUES (104, 303);
INSERT INTO Motherhood(ChildID, MotherID)
VALUES (343, 6893)

INSERT INTO Fatherhood (ChildID, FatherID)
VALUES (99, 3)

INSERT INTO Fatherhood (ChildID, FatherID)
VALUES (341, 99)

INSERT INTO Fatherhood (ChildID, FatherID)
VALUES (342, 30)

INSERT INTO Marriage VALUES (30, 303);
INSERT INTO Marriage VALUES (99, 6893);
INSERT INTO Marriage VALUES (2, 3);
INSERT INTO Marriage VALUES (2, 88);
INSERT INTO Marriage VALUES (30, 6893);

-- Select all records from the our table

SELECT *
FROM Person_Address;
SELECT *
FROM Person;
SELECT *
FROM Education_History;
SELECT *
FROM Person_attends_school;
SELECT *
FROM Work_History;
SELECT *
FROM Events;
SELECT *
FROM Motherhood;
SELECT *
FROM Fatherhood;
SELECT *
FROM Marriage;
SELECT *
FROM Person_Education_View;

